library(testthat)
test_check("CrispRVariants")